//
//  AnimationLikeButton.h
//  CoreAnimation
//
//  Created by Mini001 on 2021/12/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AnimationLikeButton : UIButton

@end

NS_ASSUME_NONNULL_END
