//
//  AppDelegate.h
//  CoreAnimation
//
//  Created by Mini001 on 2021/12/6.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end

